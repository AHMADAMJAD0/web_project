CREATE DATABASE bsc21242;

USE bsc21242;


CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,   -- Primary key for course identification
    name VARCHAR(255) NOT NULL,    -- Course name
    departmentid INT,
    departmentname VARCHAR(255) NOT NULL, -- Department offering the course
    image VARCHAR(255)                   -- Path or URL to the course image
);




-- Insert entry 1
INSERT INTO courses (departmentname, name, departmentid,  image)
VALUES ('Bussines & Finnance', 'BBA (Hons.) Banking & Finance', 4 ,'assets/images/courses/pic1.jpg');

-- Insert entry 2
INSERT INTO courses (departmentname, name,departmentid,  image)
VALUES ('Information Technology', 'BS Computer Science', 1 ,'assets/images/courses/pic2.jpg');

-- Insert entry 3
INSERT INTO courses (departmentname, name,departmentid,  image)
VALUES ('Information Technology', 'BS Information technology', 1 ,'assets/images/courses/pic6.jpg');

-- Insert entry 4
INSERT INTO courses (departmentname, name,departmentid, image)
VALUES ('English And Lit.', 'English Language', 2 , 'assets/images/courses/pic3.jpg');

-- Insert entry 5
INSERT INTO courses (departmentname, name,departmentid,  image)
VALUES ('Law', 'BS Law Honor', 5, 'assets/images/courses/pic4.jpg');

-- Insert entry 6
INSERT INTO courses (departmentname, name, departmentid, image)
VALUES ('Commerce', 'BS Import/Export', 3 , 'assets/images/courses/pic5.jpg');


